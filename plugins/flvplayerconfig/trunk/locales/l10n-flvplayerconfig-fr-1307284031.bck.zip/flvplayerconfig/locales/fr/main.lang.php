<?php
// Language: Français 
// Module: flvplayerconfig - 1.6
// Date: 2011-06-04 14:33:41 
// Translated with dcTranslater - 1.5 

#_admin.php:18
$GLOBALS['__l10n']['flvPlayer config'] = 'FLV Player config';

#form.php:173
$GLOBALS['__l10n']['Configuration successfully updated.'] = 'Configuration mise à jour.';

#form.php:178
#form.php:186
$GLOBALS['__l10n']['FLV Player Config'] = 'FLV Player Config';

#form.php:203
$GLOBALS['__l10n']['Fast'] = 'Rapide';

#form.php:207
$GLOBALS['__l10n']['Video size'] = 'Taille de la vidéo';

#form.php:208
#form.php:249
$GLOBALS['__l10n']['Width'] = 'Forcer la largeur de la vidéo';

#form.php:211
#form.php:252
$GLOBALS['__l10n']['Height'] = 'Forcer la hauteur de la vidéo';

#form.php:219
#form.php:220
#form.php:255
$GLOBALS['__l10n']['Disposition'] = 'Alignement de la vidéo';

#form.php:222
#form.php:257
$GLOBALS['__l10n']['None'] = 'Aucun';

#form.php:223
#form.php:258
$GLOBALS['__l10n']['Left'] = 'Gauche';

#form.php:224
#form.php:259
$GLOBALS['__l10n']['Right'] = 'Droite';

#form.php:225
#form.php:260
$GLOBALS['__l10n']['Center'] = 'Centre';

#form.php:236
#form.php:240
$GLOBALS['__l10n']['General'] = 'Général';

#form.php:241
#form.php:330
#form.php:355
$GLOBALS['__l10n']['Title'] = 'Titre';

#form.php:244
$GLOBALS['__l10n']['Startimage'] = 'URL de l\'image afficher avant la vidéo';

#form.php:266
$GLOBALS['__l10n']['Loop'] = 'Boucler';

#form.php:270
$GLOBALS['__l10n']['Autoplay'] = 'Lecture automatique';

#form.php:274
$GLOBALS['__l10n']['Autoload'] = 'Chargement automatique';

#form.php:294
$GLOBALS['__l10n']['Miscellaneous'] = 'Divers';

#form.php:295
$GLOBALS['__l10n']['Show mouse'] = 'Afficher la souris';

#form.php:297
#form.php:440
#form.php:447
$GLOBALS['__l10n']['autohide'] = 'Masquer automatiquement';

#form.php:298
#form.php:441
#form.php:448
$GLOBALS['__l10n']['always'] = 'Toujours';

#form.php:299
#form.php:442
#form.php:449
$GLOBALS['__l10n']['never'] = 'Jamais';

#form.php:302
$GLOBALS['__l10n']['Video background color'] = 'Couleur du fond de la vidéo quand il n\'y a pas de vidéo';

#form.php:307
$GLOBALS['__l10n']['Load on stop'] = 'Arrêter le chargement de la vidéo au STOP';

#form.php:311
$GLOBALS['__l10n']['PHP stream'] = 'Utiliser un streaming php';

#form.php:315
$GLOBALS['__l10n']['Shortcut'] = 'Raccourcis';

#form.php:317
$GLOBALS['__l10n']['Net connection'] = 'URL du serveur RTMP';

#form.php:322
$GLOBALS['__l10n']['Show title and startimage'] = 'Afficher le titre et l\'image de départ en même temps';

#form.php:330
#form.php:334
$GLOBALS['__l10n']['Border'] = 'Bordure';

#form.php:338
$GLOBALS['__l10n']['Margin'] = 'Marge';

#form.php:341
$GLOBALS['__l10n']['Background color'] = 'Couleur de fond';

#form.php:344
$GLOBALS['__l10n']['Background color 1'] = 'Couleur de fond 1';

#form.php:347
$GLOBALS['__l10n']['Background color 2'] = 'Couleur de fond 2';

#form.php:356
$GLOBALS['__l10n']['Title color'] = 'Couleur du titre';

#form.php:359
$GLOBALS['__l10n']['Title size'] = 'Taille du titre';

#form.php:385
#form.php:388
$GLOBALS['__l10n']['Subtitle'] = 'Sous-titres';

#form.php:390
$GLOBALS['__l10n']['Subtitle color'] = 'Couleur sous-titres';

#form.php:393
$GLOBALS['__l10n']['Subtitle background color'] = 'Couleur de fond de sous-titres';

#form.php:396
$GLOBALS['__l10n']['Subtitle size'] = 'Taille de sous-titres';

#form.php:409
$GLOBALS['__l10n']['Subtitle url'] = 'Url de sous-titres';

#form.php:418
#form.php:422
$GLOBALS['__l10n']['Control Bar'] = 'Barre de contrôle';

#form.php:425
$GLOBALS['__l10n']['Show stop'] = 'Afficher boutton stop';

#form.php:429
$GLOBALS['__l10n']['Show volume'] = 'Afficher boutton volume';

#form.php:431
$GLOBALS['__l10n']['Show time'] = 'Afficher l\'heure';

#form.php:438
$GLOBALS['__l10n']['Show player'] = 'Afficher player';

#form.php:445
$GLOBALS['__l10n']['Show loading'] = 'Voir le chargement';

#form.php:454
$GLOBALS['__l10n']['Show full screen'] = 'Afficher en plein écran';

#form.php:468
$GLOBALS['__l10n']['Colors'] = 'Couleurs';

#form.php:469
$GLOBALS['__l10n']['Player color'] = 'La couleur du joueur';

#form.php:472
$GLOBALS['__l10n']['Player alpha'] = 'Transparence';

#form.php:481
$GLOBALS['__l10n']['Loading color'] = 'Couleur du loadeur';

#form.php:484
$GLOBALS['__l10n']['Button color'] = 'Couleur des boutons';

#form.php:487
$GLOBALS['__l10n']['Button over color'] = 'Couleur des boutons au survole';

#form.php:490
$GLOBALS['__l10n']['Slider color 1'] = 'Première couleur du Slider';

#form.php:493
$GLOBALS['__l10n']['Slider color 2'] = 'Deuxième couleur du Slider';

#form.php:496
$GLOBALS['__l10n']['Slider over color'] = 'Couleur du Slider au survole';

#form.php:505
$GLOBALS['__l10n']['Technical'] = 'Technique';

#form.php:509
$GLOBALS['__l10n']['Display Buffer'] = 'Buffer d\'affichage';

#form.php:519
$GLOBALS['__l10n']['Buffer message'] = 'message pendant le Buffer';

#form.php:522
$GLOBALS['__l10n']['Buffer color'] = 'Couleur du Buffer';

#form.php:525
$GLOBALS['__l10n']['Buffer background color'] = 'Couleur de fond du Buffer';

#form.php:530
$GLOBALS['__l10n']['Buffer show background'] = 'Fond pendant le Buffer';

#form.php:537
$GLOBALS['__l10n']['Controls the mouse'] = 'Contrôles de la souris';

#form.php:556
#form.php:560
$GLOBALS['__l10n']['Images on the video'] = 'Images sur la vidéo';

#form.php:556
#form.php:581
$GLOBALS['__l10n']['The icons of the video'] = 'Les icônes de la vidéo';

#form.php:584
$GLOBALS['__l10n']['Show icon play'] = 'Afficher les icônes de la vidéo';

#form.php:586
$GLOBALS['__l10n']['Icon play color'] = 'Couleur de l\'icône play';

#form.php:589
$GLOBALS['__l10n']['Icon play background color'] = 'Couleur du background de l\'icône play';

#form.php:592
$GLOBALS['__l10n']['Icon play background alpha'] = 'transparence du background de l\'icône play';

#form.php:611
#form.php:613
$GLOBALS['__l10n']['OK'] = 'Valider';

#inc/class.dc.flvplayerconfig.php:29
$GLOBALS['__l10n']['Enable flvplayerconfig'] = 'Activer FLV Player config';

#inc/class.lipki.utils.php:21
$GLOBALS['__l10n']['Plugins Enable'] = 'Activer les Plugins';

?>