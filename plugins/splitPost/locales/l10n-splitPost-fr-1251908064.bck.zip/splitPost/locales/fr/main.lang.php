<?php
// Language: français 
// Module: splitPost - 0.1
// Date: 2009-09-02 16:13:40 
// Author: displayBouron, tbouron@gmail.com
// Translated with dcTranslater - 0.2.4 

?>