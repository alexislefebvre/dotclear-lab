<?php
// Language: français 
// Module: puzzle - 0.1
// Date: 2009-10-28 11:21:20 
// Translated with dcTranslater - 1.3 

?>