<?php
// Language: Français 
// Module: lePluginDuJour - 0.1
// Date: 2010-10-10 08:47:16 
// Translated with dcTranslater - 1.5 

?>