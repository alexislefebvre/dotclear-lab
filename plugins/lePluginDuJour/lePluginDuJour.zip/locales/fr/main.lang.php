<?php
// Language: Français 
// Module: lePluginDuJour - 0.1
// Date: 2010-10-10 08:56:06 
// Translated with dcTranslater - 1.5 

#_admin.php:43
$GLOBALS['__l10n']['More details'] = 'En savoir plus';

?>