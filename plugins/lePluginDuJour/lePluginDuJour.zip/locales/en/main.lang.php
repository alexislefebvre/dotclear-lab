<?php
// Language: English 
// Module: lePluginDuJour - 0.1
// Date: 2010-10-10 08:53:35 
// Translated with dcTranslater - 1.5 

#_admin.php:42
$GLOBALS['__l10n']['by'] = 'by';

#_admin.php:43
$GLOBALS['__l10n']['More details'] = 'More details';

#inc/class.leplugindujour.php:260
$GLOBALS['__l10n']['An error occurred while downloading the file.'] = 'An error occurred while downloading the file.';

?>