<?php
// Language: français 
// Module: translater v0.3
// Date: 2009-04-25 21:14:39 
// File made by translater - 0.2.2 

# index.php:60
$GLOBALS['__l10n']['Translation successfully updated'] = 'Taduction mise à jour avec succès';

# index.php:61
$GLOBALS['__l10n']['Translation successfully created'] = 'Traduction crée avec succès';

# index.php:62
$GLOBALS['__l10n']['Translation successfully deleted'] = 'Traduction effacer avec succès';

# index.php:63
$GLOBALS['__l10n']['Backups successfully create'] = 'Sauvegardes crées avec succès';

# index.php:64
$GLOBALS['__l10n']['Backups successfully restored'] = 'Sauvegardes effectuées avec succès';

# index.php:65
$GLOBALS['__l10n']['Backups successfully deleted'] = 'Sauvegardes effacées avec succès';

# index.php:66
$GLOBALS['__l10n']['Package successfully imported'] = 'Paquetage importé avec succès';

# index.php:67
$GLOBALS['__l10n']['Package successfully exported'] = 'Paquetage exporté avec succès';

# index.php:72
$GLOBALS['__l10n']['Failed to update settings: %s'] = 'Impossible de mettre à jour les paramètres : %s';

# index.php:73
$GLOBALS['__l10n']['Failed to update translation: %s'] = 'Impossible de mettre à jour la traduction : %s';

# index.php:74
$GLOBALS['__l10n']['Failed to create translation: %s'] = 'Impossible de créer la traduction : %s';

# index.php:75
$GLOBALS['__l10n']['Failed to delete translation: %s'] = 'Impossible d\'effacer la traduction : %s';

# index.php:76
$GLOBALS['__l10n']['Failed to create backups: %s'] = 'Impossible de créer les sauvegardes : %s';

# index.php:77
$GLOBALS['__l10n']['Failed to restore backups: %s'] = 'Impossible de restaurer : %s';

# index.php:78
$GLOBALS['__l10n']['Failed to delete backups: %s'] = 'Impossible d\'effacer les sauvegardes : %s';

# index.php:79
$GLOBALS['__l10n']['Failed to import package: %s'] = 'Impossible d\'importer le paquetage : %s';

# index.php:80
$GLOBALS['__l10n']['Failed to export package: %s'] = 'Impossible d\'exporter le paquetage : %s';

# index.php:89
$GLOBALS['__l10n']['Failed to launch translater: %s'] = 'Impossible de démarrer translater : %s';

# index.php:180
$GLOBALS['__l10n']['Nothing to restore'] = 'Rien à restaurer';

# index.php:199
$GLOBALS['__l10n']['Nothing to backup'] = 'Rien à sauvegarder';

?>