<?php
// Language: français 
// Module: translater - 0.6
// Date: 2009-05-01 15:51:52 
// Author: JC Denis, http://blog.jcdenis.com
// Translated with dcTranslater - 0.2.4 

#index.php:66
$GLOBALS['__l10n']['Translation successfully updated'] = 'Traduction mise à jour avec succès';

#index.php:67
$GLOBALS['__l10n']['Translation successfully created'] = 'Traduction crée avec succès';

#index.php:68
$GLOBALS['__l10n']['Translation successfully deleted'] = 'Traduction effacée avec succès';

#index.php:69
$GLOBALS['__l10n']['Backups successfully create'] = 'Sauvegardes crées avec succès';

#index.php:70
$GLOBALS['__l10n']['Backups successfully restored'] = 'Sauvegardes effectuées avec succès';

#index.php:71
$GLOBALS['__l10n']['Backups successfully deleted'] = 'Sauvegardes effacées avec succès';

#index.php:72
$GLOBALS['__l10n']['Package successfully imported'] = 'Paquetage importé avec succès';

#index.php:73
$GLOBALS['__l10n']['Package successfully exported'] = 'Paquetage exporté avec succès';

#index.php:78
$GLOBALS['__l10n']['Failed to update settings: %s'] = 'Impossible de mettre à jour les paramètres : %s';

#index.php:79
$GLOBALS['__l10n']['Failed to update translation: %s'] = 'Impossible de mettre à jour la traduction : %s';

#index.php:80
$GLOBALS['__l10n']['Failed to create translation: %s'] = 'Impossible de créer la traduction : %s';

#index.php:81
$GLOBALS['__l10n']['Failed to delete translation: %s'] = 'Impossible d\'effacer la traduction : %s';

#index.php:82
$GLOBALS['__l10n']['Failed to create backups: %s'] = 'Impossible de créer les sauvegardes : %s';

#index.php:83
$GLOBALS['__l10n']['Failed to restore backups: %s'] = 'Impossible de restaurer les sauvegardes : %s';

#index.php:84
$GLOBALS['__l10n']['Failed to delete backups: %s'] = 'Impossible d\'effacer les sauvegardes : %s';

#index.php:85
$GLOBALS['__l10n']['Failed to import package: %s'] = 'Impossible d\'importer le paquetage : %s';

#index.php:86
$GLOBALS['__l10n']['Failed to export package: %s'] = 'Impossible d\'exporter le paquetage : %s';

#index.php:95
$GLOBALS['__l10n']['Failed to launch translater: %s'] = 'Impossible de démarrer translater : %s';

#index.php:128
$GLOBALS['__l10n']['Nothing to update'] = 'Rien à mettre à jour';

#index.php:180
$GLOBALS['__l10n']['Nothing to restore'] = 'Rien à restaurer';

#index.php:199
$GLOBALS['__l10n']['Nothing to backup'] = 'Rien à sauvegarder';

#index.php:216
$GLOBALS['__l10n']['Nothing to export'] = 'Rien à exporter';

?>